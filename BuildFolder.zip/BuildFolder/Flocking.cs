﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flocking : Vehicle
{
    public GameObject seekTarget;

    public float maxForce = 2.5f;
    public float radius = 15.0f;

    public Material mat1;

    // Start is called before the first frame update
    void Start()
    {
        base.Start();
    }

    public override Vector3 CalcSteeringForce()
    {
        Vector3 ultForce = Vector3.zero;
        Vector3 desVel = manager.averageDirection;
        Vector3 center = manager.flockCenter;

        desVel.Normalize();
        desVel *= maxSpeed;
        desVel = desVel - velocity;


        ultForce += Seek(seekTarget.transform.position);
        ultForce += desVel;
        ultForce += Seek(center);

        Vector3.ClampMagnitude(ultForce, maxForce);

        return ultForce;
    }

    public override Vector3 SeparationForce()
    {
        Vector3 ultForce = Vector3.zero;

        for(int i=0; i < manager.flockObjects.Count; i++)
        {
            float distBetweenObjects = Vector3.Distance(transform.position, manager.flockObjects[i].transform.position);

            if(distBetweenObjects < 3.0f)
            {
                Vector3 separateObjs = Flee(manager.flockObjects[i].transform.position);
                ultForce += separateObjs;
            }
        }
        Vector3.ClampMagnitude(ultForce, maxForce);
        return ultForce;
    }

    public override Vector3 AvoidObstacle(GameObject obstacle)
    {
        Vector3 vecToCenter = obstacle.transform.position - transform.position;
        float dotForward = Vector3.Dot(vecToCenter, transform.forward);
        float dotRight = Vector3.Dot(vecToCenter, transform.right);
        float radiiSum = manager.radius + radius;

        if (dotForward < 0)
        {
            return Vector3.zero;
        }

        if (vecToCenter.magnitude > 30)
        {
            return Vector3.zero;
        }

        if (radiiSum < Mathf.Abs(dotRight))
        {
            return Vector3.zero;
        }

        Vector3 desiredVelocity;

        if (dotRight < 0)
        {
            desiredVelocity = transform.right * maxSpeed;
        }
        else
        {
            desiredVelocity = -transform.right * maxSpeed;
        }


        Vector3 steeringForce = desiredVelocity - velocity;
        return steeringForce;
    }


}
