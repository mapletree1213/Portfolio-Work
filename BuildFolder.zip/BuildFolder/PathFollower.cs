﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathFollower : MonoBehaviour
{
    public Transform[] pathToFollow;
    public float speedOfFollower = 1.5f;
    public float radius = 0.2f;
    public int pathIndex = 0;
    bool isActive = false;

    // Start is called before the first frame update
    void Start()
    {

    }

    void Update()
    {
        float distance = Vector3.Distance(pathToFollow[pathIndex].position, transform.position);

        transform.position = Vector3.MoveTowards(transform.position, pathToFollow[pathIndex].position, Time.deltaTime*speedOfFollower);
        transform.forward = pathToFollow[pathIndex].transform.position;

        if (distance <= radius)
        {
            pathIndex++;
        }

        if (pathIndex >= pathToFollow.Length)
        {
            pathIndex = 0;
        }

        //if (Input.GetKeyDown(KeyCode.C))
        //{
        //    isActive = !isActive;

        //    if (isActive)
        //    {
        //    Debug.DrawLine(pathToFollow[0].position, pathToFollow[1].position, Color.black);
        //    Debug.DrawLine(pathToFollow[1].position, pathToFollow[2].position, Color.black);
        //    Debug.DrawLine(pathToFollow[2].position, pathToFollow[3].position, Color.black);
        //    Debug.DrawLine(pathToFollow[3].position, pathToFollow[4].position, Color.black);
        //    Debug.DrawLine(pathToFollow[4].position, pathToFollow[5].position, Color.black);
        //    Debug.DrawLine(pathToFollow[5].position, pathToFollow[6].position, Color.black);
        //    Debug.DrawLine(pathToFollow[6].position, pathToFollow[0].position, Color.black);
        //    }

        //}


        Debug.DrawLine(pathToFollow[0].position, pathToFollow[1].position, Color.black);
        Debug.DrawLine(pathToFollow[1].position, pathToFollow[2].position, Color.black);
        Debug.DrawLine(pathToFollow[2].position, pathToFollow[3].position, Color.black);
        Debug.DrawLine(pathToFollow[3].position, pathToFollow[4].position, Color.black);
        Debug.DrawLine(pathToFollow[4].position, pathToFollow[5].position, Color.black);
        Debug.DrawLine(pathToFollow[5].position, pathToFollow[6].position, Color.black);
        Debug.DrawLine(pathToFollow[6].position, pathToFollow[0].position, Color.black);


    }

    //Draws debug for nodes
    void OnDrawGizmos()
    {
        if (pathToFollow.Length > 0)
        {
            for (int i = 0; i < pathToFollow.Length; i++)
            {
                if (pathToFollow[i] != null)
                {
                    Gizmos.DrawSphere(pathToFollow[i].position, radius);
                }
            }
        }
    }





}
