﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cams : MonoBehaviour
{
    Camera[] cams;
    int camIndex;

    // Start is called before the first frame update
    void Start()
    {
        cams = gameObject.GetComponentsInChildren<Camera>();
        camIndex = 0;
        DisableOtherCams();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            camIndex++;
            camIndex %= cams.Length;
            DisableOtherCams();
        }
    }

    void DisableOtherCams()
    {
        cams[camIndex].enabled = true;

        for(int i = 0; i < cams.Length; i++)
        {
            if (i != camIndex)
            {
                cams[i].enabled = false;
            }
        }
    }
}
