﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour
{

    //variables
    public GameObject flock;
    public GameObject objToSeek;
    public GameObject centerOfFlock;

    GameObject seekingObj;
    GameObject seekingObj2;

    public List<GameObject> flockObjects;

    public Vector3 averageDirection;
    public Vector3 flockCenter;

    public float xDataMax;
    public float yDataMax;
    public float zDataMax;
    public float radius;


    // Start is called before the first frame update
    void Start()
    {
        //Sets up terrain bounds
        xDataMax = GameObject.Find("Terrain").GetComponent<Terrain>().terrainData.size.x;
        yDataMax = GameObject.Find("Terrain").GetComponent<Terrain>().terrainData.size.y;
        zDataMax = GameObject.Find("Terrain").GetComponent<Terrain>().terrainData.size.z;
        radius = 15.0f;

        //Instantiate one object for flock to seek
        seekingObj = Instantiate(objToSeek, new Vector3(Random.Range(0, xDataMax),
                                                    Random.Range(0, yDataMax),
                                                    Random.Range(0, zDataMax)),
               
                                                    Quaternion.identity);
        //Spawns in flockingObjs into scene
        SpawnFlockObjs();
    }

    // Update is called once per frame
    void Update()
    {
        CheckFlockMovement();
    }

    void SpawnFlockObjs()
    {
        for(int i=0; i < 10; i++)
        {
            //Instantiates flockingObjs
            GameObject flockObj = Instantiate(flock,new Vector3(Random.Range(0,xDataMax),
                                                                Random.Range(0,yDataMax),
                                                                Random.Range(0,zDataMax)),
                                                                Quaternion.identity);
            //sets the flockObj seekingtarget to the one instantiated
            flockObj.GetComponent<Flocking>().seekTarget = seekingObj;

            //Adds the instantiated objects to list
            flockObjects.Add(flockObj);
        }
    }

    void CheckFlockMovement()
    {
        averageDirection = Vector3.zero;
        flockCenter = Vector3.zero;

        for(int i=0; i < flockObjects.Count; i++)
        {

            //distance variable which is from the flockobj position and the
            //object that they're seeking's position
            float distanceBetween = Vector3.Distance(flockObjects[i].transform.position, seekingObj.transform.position);

            //if distance between flock and the object they're seeking is less than this amt
            //change the object's location to a new random position
            if (distanceBetween < 2.0f)
            {
                seekingObj.transform.position = new Vector3(Random.Range(0, xDataMax),
                                                                Random.Range(0, yDataMax),
                                                                Random.Range(0, zDataMax));
            }

            //computes direction and center of flock
            averageDirection += flockObjects[i].transform.forward;
            flockCenter += flockObjects[i].transform.position;
        }

        //sets the center and directional alignment
        averageDirection = averageDirection / flockObjects.Count;
        flockCenter = flockCenter / flockObjects.Count;

        //sets the centerofflock object to that position and the direction
        //that the flock is going
        centerOfFlock.transform.position = flockCenter;
        centerOfFlock.transform.position = averageDirection;
    }
}
