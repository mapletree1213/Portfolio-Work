﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Vehicle : MonoBehaviour
{
    //properties
    protected Vector3 objPosition;
    public Vector3 direction;
    public Vector3 velocity;
    public Vector3 acceleration;
    public float mass;
    public float maxSpeed;

    public Manager manager;

    //abstract methods
    public abstract Vector3 CalcSteeringForce();
    public abstract Vector3 AvoidObstacle(GameObject obstacle);
    public abstract Vector3 SeparationForce();

    // Start is called before the first frame update
    protected void Start()
    {
        objPosition = transform.position;
        maxSpeed = 5.0f;
        velocity = Vector3.zero;

        manager = GameObject.Find("GameManager").GetComponent<Manager>();
    }

    // Update is called once per frame
    void Update()
    {
        ApplyForces(CalcSteeringForce());
        ApplyForces(SeparationForce());

        velocity += acceleration * Time.deltaTime;
        objPosition += velocity * Time.deltaTime;
        direction = velocity.normalized;
        acceleration = Vector3.zero;
        transform.position = objPosition;
        transform.forward = velocity;
    }

    //apply force method
    public void ApplyForces(Vector3 force)
    {
        acceleration += force / mass;
    }

    //default seek method
    public Vector3 Seek(Vector3 target)
    {
        Vector3 desiredVelocity = target - objPosition;
        desiredVelocity.Normalize();
        desiredVelocity *= maxSpeed;
        Vector3 seekVec = desiredVelocity - velocity;
        return seekVec;
    }

    //seek method based on gameobject
    public Vector3 Seek(GameObject target)
    {
        return Seek(target.transform.position);
    }

    //default flee method
    public Vector3 Flee(Vector3 targetPosition)
    {
        Vector3 desiredVelocity = objPosition - targetPosition;
        desiredVelocity.Normalize();

        desiredVelocity = desiredVelocity * maxSpeed;
        Vector3 fleeForce = desiredVelocity - velocity;

        return fleeForce;
    }

    //flee method based on gameobject
    public Vector3 Flee(GameObject target)
    {
        return Flee(target.transform.position);
    }
}
