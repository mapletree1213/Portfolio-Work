#include "Renderer.h"
#include "SimpleShader.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx11.h"
#include <DirectXMath.h>


using namespace DirectX;


Renderer::Renderer(Microsoft::WRL::ComPtr<ID3D11Device> device,
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> context,
	Microsoft::WRL::ComPtr<IDXGISwapChain> swapChain,
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> backBufferRTV,
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depthBufferDSV,
	unsigned int windowWidth, unsigned int windowHeight,
	Sky* sky,
	const std::vector<GameEntity*>& entities, const std::vector<Light>& lights,
	Mesh* lightMesh,
	SimpleVertexShader* lightVS,
	SimplePixelShader* lightPS,
	SimplePixelShader* refPS,
	SimplePixelShader* simpleTextPS,
	SimpleVertexShader* fullScreenVS,
	DirectX::SpriteFont* arial,
	DirectX::SpriteBatch* spriteBatch) :
		entities(entities),
		lights(lights),
		sky(sky),
		windowHeight(windowHeight),
		windowWidth(windowWidth),
		swapChain(swapChain),
		context(context),
		device(device),
		backBufferRTV(backBufferRTV),
		depthBufferDSV(depthBufferDSV),
		lightVS(lightVS),
		lightPS(lightPS),
		refPS(refPS),
		simpleTextPS(simpleTextPS),
		fullScreenVS(fullScreenVS),
		lightMesh(lightMesh),
		arial(arial),
		spriteBatch(spriteBatch),
		indexOfRefraction(0.5f),
		refractionScale(0.1f)
{
	

	D3D11_TEXTURE2D_DESC texDesc= {};
	texDesc.Width = windowWidth;
	texDesc.Height = windowHeight;
	texDesc.ArraySize = 1;
	texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	// Need both!
	texDesc.Format= DXGI_FORMAT_R8G8B8A8_UNORM; 
	// Might occasionally use other formats
	texDesc.MipLevels= 1; 
	// Usually no mipchain needed for render targets
	texDesc.MiscFlags= 0;
	texDesc.SampleDesc.Count= 1;  
	// Can't be zero
	device->CreateTexture2D(&texDesc, 0, rtTexture.GetAddressOf()); 

	D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {}; 
	rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D; 
	// This points to a Texture2D
	rtvDesc.Texture2D.MipSlice = 0;                             
	// Which mipare we rendering into?
	rtvDesc.Format= texDesc.Format;                
	// Same format as texture
	device->CreateRenderTargetView(rtTexture.Get(), &rtvDesc, sceneColorsRTV.GetAddressOf());
	device->CreateShaderResourceView(rtTexture.Get(),                 // Texture resource itself
		0,                         									  // Null description = default SRV options
		sceneColorsSRV.GetAddressOf());									//  ComPtr<ID3D11ShaderResourceView>
}

Renderer::~Renderer()
{
}

void Renderer::PostResize(unsigned int wW, unsigned int wH, Microsoft::WRL::ComPtr<ID3D11RenderTargetView> backBufferRTV, Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depthBufferDSV)
{
	windowWidth = wW;
	windowHeight = wH;
	backBufferRTV = backBufferRTV;
	depthBufferDSV = depthBufferDSV;
	Microsoft::WRL::ComPtr<ID3D11Texture2D> rtTexture;

	D3D11_TEXTURE2D_DESC texDesc = {};
	texDesc.Width = windowWidth;
	texDesc.Height = windowHeight;
	texDesc.ArraySize = 1;
	texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	// Need both!
	texDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	// Might occasionally use other formats
	texDesc.MipLevels = 1;
	// Usually no mipchain needed for render targets
	texDesc.MiscFlags = 0;
	texDesc.SampleDesc.Count = 1;
	// Can't be zero
	device->CreateTexture2D(&texDesc, 0, rtTexture.GetAddressOf());

	D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
	rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
	// This points to a Texture2D
	rtvDesc.Texture2D.MipSlice = 0;
	// Which mipare we rendering into?
	rtvDesc.Format = texDesc.Format;
	// Same format as texture
	device->CreateRenderTargetView(rtTexture.Get(), &rtvDesc, sceneColorsRTV.GetAddressOf());
	device->CreateShaderResourceView(rtTexture.Get(),                 // Texture resource itself
		0,                         									  // Null description = default SRV options
		sceneColorsSRV.GetAddressOf());									//  ComPtr<ID3D11ShaderResourceView>
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Renderer::GetRenderTargetSRV() {
	return sceneColorsSRV;
}

void Renderer::Render(Camera* camera, int numOfLights)
{
	// Background color for clearing
	const float color[4] = { 0, 0, 0, 1 };

	// Clear the render target and depth buffer (erases what's on the screen)
	//  - Do this ONCE PER FRAME
	//  - At the beginning of Draw (before drawing *anything*)
	context->ClearRenderTargetView(backBufferRTV.Get(), color);
	context->ClearDepthStencilView(
		depthBufferDSV.Get(),
		D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL,
		1.0f,
		0);

	context->ClearRenderTargetView(sceneColorsRTV.Get(), color);
	ID3D11RenderTargetView* renderTargets[1] = {}; 
	renderTargets[0] = sceneColorsRTV.Get();
	context->OMSetRenderTargets(1, renderTargets, depthBufferDSV.Get());

	
	

	// Draw all of the entities
	for (auto ge : entities)
	{
		if (ge->GetMaterial()->GetRefract() == true) {
			continue;
		}
		// Set the "per frame" data
		// Note that this should literally be set once PER FRAME, before
		// the draw loop, but we're currently setting it per entity since 
		// we are just using whichever shader the current entity has.  
		// Inefficient!!!
		SimplePixelShader* ps = ge->GetMaterial()->GetPS();

		ps->SetShaderResourceView("IrradianceIBLMap", sky->GetIrradiance());
		ps->SetShaderResourceView("SpecularIBLMap", sky->GetConvolved());
		ps->SetShaderResourceView("BrdfLookUpMap", sky->GetLookUp());
		ps->SetData("Lights", (void*)(&lights[0]), sizeof(Light) * numOfLights);
		ps->SetInt("LightCount", numOfLights);
		ps->SetFloat3("CameraPosition", camera->GetTransform()->GetPosition());
		ps->SetInt("SpecIBLTotalMipLevels", sky->GetMipLevels());
		ps->CopyBufferData("perFrame");

		// Draw the entity
		ge->Draw(context, camera);
	}

	// Draw the light sources
	DrawPointLights(camera, numOfLights);



	// Draw the sky
	sky->Draw(camera);
	 
	context->OMSetRenderTargets(1, backBufferRTV.GetAddressOf(), 0);

	//Render fullscreenVS, render scenecolors image
	SimplePixelShader* scenePS = simpleTextPS;
	SimpleVertexShader* fullVS = fullScreenVS;
	fullVS->SetShader();
	scenePS->SetShader();
	scenePS->SetShaderResourceView("Pixels", sceneColorsSRV);
	context->Draw(3, 0);

	context->OMSetRenderTargets(1, backBufferRTV.GetAddressOf(), depthBufferDSV.Get());


	//Set Refraction PixelShader
	std::vector<GameEntity*> refEntity;
	for (auto ge : entities) {
		if (ge->GetMaterial()->GetRefract()) {
			refEntity.push_back(ge);
			continue;
		}
	}

	for (auto ge : refEntity) {
		Material* refMat = ge->GetMaterial();
		SimplePixelShader* previousPS = refMat->GetPS();
		refMat->SetPS(refPS);

		refMat->PrepareMaterial(ge->GetTransform(), camera);
		refPS->SetFloat2("screenSize", XMFLOAT2((float)windowWidth, (float)windowHeight));
		refPS->SetMatrix4x4("viewMatrix", camera->GetView());
		refPS->SetMatrix4x4("projMatrix", camera->GetProjection());
		refPS->SetFloat("indexOfRefraction", indexOfRefraction);
		refPS->SetFloat("refractionScale", refractionScale);
		refPS->CopyBufferData("perObject");

		refPS->SetShaderResourceView("ScreenPixels", sceneColorsSRV);

		ge->GetMesh()->SetBuffersAndDraw(context);
		refMat->SetPS(previousPS);
	}

	// Draw some UI
	DrawUI();

	//Draw ImGui
	ImGui::Render();
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());


	// Present the back buffer to the user
	//  - Puts the final frame we're drawing into the window so the user can see it
	//  - Do this exactly ONCE PER FRAME (always at the very end of the frame)
	swapChain->Present(0, 0);

	// Due to the usage of a more sophisticated swap chain,
	// the render target must be re-bound after every call to Present()
	context->OMSetRenderTargets(1, backBufferRTV.GetAddressOf(), depthBufferDSV.Get());

}

void Renderer::DrawPointLights(Camera* camera, int numOfLights)
{
	// Turn on these shaders
	lightVS->SetShader();
	lightPS->SetShader();

	// Set up vertex shader
	lightVS->SetMatrix4x4("view", camera->GetView());
	lightVS->SetMatrix4x4("projection", camera->GetProjection());

	for (int i = 0; i < numOfLights; i++)
	{
		Light light = lights[i];

		// Only drawing points, so skip others
		if (light.Type != LIGHT_TYPE_POINT)
			continue;

		// Calc quick scale based on range
		// (assuming range is between 5 - 10)
		float scale = light.Range / 10.0f;

		// Make the transform for this light
		XMMATRIX rotMat = XMMatrixIdentity();
		XMMATRIX scaleMat = XMMatrixScaling(scale, scale, scale);
		XMMATRIX transMat = XMMatrixTranslation(light.Position.x, light.Position.y, light.Position.z);
		XMMATRIX worldMat = scaleMat * rotMat * transMat;

		XMFLOAT4X4 world;
		XMFLOAT4X4 worldInvTrans;
		XMStoreFloat4x4(&world, worldMat);
		XMStoreFloat4x4(&worldInvTrans, XMMatrixInverse(0, XMMatrixTranspose(worldMat)));

		// Set up the world matrix for this light
		lightVS->SetMatrix4x4("world", world);
		lightVS->SetMatrix4x4("worldInverseTranspose", worldInvTrans);

		// Set up the pixel shader data
		XMFLOAT3 finalColor = light.Color;
		finalColor.x *= light.Intensity;
		finalColor.y *= light.Intensity;
		finalColor.z *= light.Intensity;
		lightPS->SetFloat3("Color", finalColor);

		// Copy data
		lightVS->CopyAllBufferData();
		lightPS->CopyAllBufferData();

		// Draw
		lightMesh->SetBuffersAndDraw(context);
	}
}

void Renderer::DrawUI()
{
	spriteBatch->Begin();

	// Basic controls
	float h = 10.0f;
	arial->DrawString(spriteBatch, L"Controls:", XMVectorSet(10, h, 0, 0));
	arial->DrawString(spriteBatch, L" (WASD, X, Space) Move camera", XMVectorSet(10, h + 20, 0, 0));
	arial->DrawString(spriteBatch, L" (Left Click & Drag) Rotate camera", XMVectorSet(10, h + 40, 0, 0));
	arial->DrawString(spriteBatch, L" (Left Shift) Hold to speed up camera", XMVectorSet(10, h + 60, 0, 0));
	arial->DrawString(spriteBatch, L" (Left Ctrl) Hold to slow down camera", XMVectorSet(10, h + 80, 0, 0));
	arial->DrawString(spriteBatch, L" (TAB) Randomize lights", XMVectorSet(10, h + 100, 0, 0));

	// Current "scene" info
	h = 150;
	arial->DrawString(spriteBatch, L"Scene Details:", XMVectorSet(10, h, 0, 0));
	arial->DrawString(spriteBatch, L" Top: PBR materials", XMVectorSet(10, h + 20, 0, 0));
	arial->DrawString(spriteBatch, L" Bottom: Non-PBR materials", XMVectorSet(10, h + 40, 0, 0));

	spriteBatch->End();

	// Reset render states, since sprite batch changes these!
	context->OMSetBlendState(0, 0, 0xFFFFFFFF);
	context->OMSetDepthStencilState(0, 0);
}
