#pragma once

#include <d3d11.h>
#include <DirectXMath.h>
#include <wrl/client.h> 
#include "SpriteFont.h"
#include "SpriteBatch.h"

#include "GameEntity.h"
#include "Camera.h"
#include "Lights.h"
#include "Sky.h"


class Renderer {
public:

	
	Renderer(
		Microsoft::WRL::ComPtr<ID3D11Device> device,
		Microsoft::WRL::ComPtr<ID3D11DeviceContext> context,
		Microsoft::WRL::ComPtr<IDXGISwapChain> swapChain,
		Microsoft::WRL::ComPtr<ID3D11RenderTargetView> backBufferRTV,
		Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depthBufferDSV,
		unsigned int windowWidth,
		unsigned int windowHeight,
		Sky* sky,
		const std::vector<GameEntity*>& entities,
		const std::vector<Light>& lights,
		Mesh* lightMesh,
		SimpleVertexShader* lightVS,
		SimplePixelShader* lightPS,
		SimplePixelShader* refPS,
		SimplePixelShader* simpleTextPS,
		SimpleVertexShader* fullScreenVS,
		DirectX::SpriteFont* arial,
		DirectX::SpriteBatch* spriteBatch
	);


	~Renderer();

	void PostResize(
		unsigned int wW,
		unsigned int wH,
		Microsoft::WRL::ComPtr<ID3D11RenderTargetView> backBufferRTV,
		Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depthBufferDSV
		);

	void Render(Camera* camera, int numOfLights);
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> GetRenderTargetSRV();


private:
	Microsoft::WRL::ComPtr<ID3D11Device> device;
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> context;
	Microsoft::WRL::ComPtr<IDXGISwapChain> swapChain;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> backBufferRTV;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depthBufferDSV;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> sceneColorsRTV;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> sceneColorsSRV;
	
	unsigned int windowWidth;
	unsigned int windowHeight;

	Sky* sky;

	const std::vector<GameEntity*>& entities;
	const std::vector<Light>& lights;

	// Text & ui
	DirectX::SpriteFont* arial;
	DirectX::SpriteBatch* spriteBatch;

	Mesh* lightMesh;
	SimpleVertexShader* lightVS;
	SimplePixelShader* lightPS;

	Microsoft::WRL::ComPtr<ID3D11Texture2D> rtTexture;
	SimplePixelShader* refPS;
	SimplePixelShader* simpleTextPS;
	SimpleVertexShader* fullScreenVS;
	float indexOfRefraction;
	float refractionScale;

	void DrawPointLights(Camera* camera, int numOfLights);

	void DrawUI();
};