#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <DirectXMath.h>
#include "MyMesh.h"


enum TerrainBD {
	BitDepth_8,
	BitDepth_16
};

class TerrainData : public MyMesh {
public:
	TerrainData(Microsoft::WRL::ComPtr<ID3D11Device> deviceObj, const char* heightMap, unsigned int mapHeight,  unsigned int mapWidth, TerrainBD bd, float heightScale, float lenWidScale, float uv);
	~TerrainData();


private:
	std::vector<unsigned char> heights;
	std::vector<float> finalHeight;
	int counter;
	unsigned int verticies;
	unsigned int indicies;
	unsigned int* inds;
	Vertex* vert;
	void LoadRaw8Bit(const char* heightMap, unsigned int mapHeight, unsigned int mapWidth, float heightScale, float lenWidScale, Vertex* vertex);
	void LoadRaw16Bit(const char* heightMap, unsigned int mapHeight, unsigned int mapWidth, float heightScale, float lenWidScale, Vertex* vertex);

};
