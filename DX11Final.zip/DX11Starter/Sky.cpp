#include "Sky.h"



Sky::Sky(std::shared_ptr<MyMesh> meshObj, Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerObj, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeMapObj, Microsoft::WRL::ComPtr<ID3D11Device> deviceObj)
{
	mesh = meshObj;
	mySampler = samplerObj;
	cubeSRV = cubeMapObj;
	D3D11_RASTERIZER_DESC skyRast = {};
	skyRast.FillMode = D3D11_FILL_SOLID;
	skyRast.CullMode = D3D11_CULL_FRONT;

	D3D11_DEPTH_STENCIL_DESC skyDepth = {};
	skyDepth.DepthEnable = true;
	skyDepth.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
	deviceObj->CreateRasterizerState(&skyRast, myRasterizer.GetAddressOf());
	deviceObj->CreateDepthStencilState(&skyDepth, depthBuff.GetAddressOf());
}

Sky::~Sky()
{
}

void Sky::DrawSky(Microsoft::WRL::ComPtr<ID3D11DeviceContext> deviceContext, Camera* camera)
{
	deviceContext->RSSetState(myRasterizer.Get());
	deviceContext->OMSetDepthStencilState(depthBuff.Get(),0);

	skyVertShad->SetShader();
	skyPixShad->SetShader();

	skyPixShad->SetSamplerState("basicSampler", mySampler.Get());
	skyPixShad->SetShaderResourceView("cubeMapTex", cubeSRV.Get());

	skyVertShad->SetMatrix4x4("view", camera->GetViewMatrix());
	skyVertShad->SetMatrix4x4("projection", camera->GetProjMatrix());
	skyVertShad->CopyAllBufferData();

	//draw the mesh here
	mesh->DrawMesh(deviceContext);

	deviceContext->RSSetState(0);
	deviceContext->OMSetDepthStencilState(0, 0);

}

void Sky::SetSkyPixelShader(std::shared_ptr<SimplePixelShader> pixShad)
{
	skyPixShad = pixShad;
}

void Sky::SetSkyVertexShader(std::shared_ptr<SimpleVertexShader> vertShad)
{
	skyVertShad = vertShad;
}

void Sky::SetSkyMesh(std::shared_ptr<MyMesh> myMeshObj)
{
	mesh = myMeshObj;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Sky::GetSkySRV()
{
	return cubeSRV;
}
