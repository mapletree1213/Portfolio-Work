#pragma once
#include "DXCore.h"
#include <d3d11.h>
#include <wrl/client.h>
#include <iostream>
#include "MyMesh.h"
#include "SimpleShader.h"
#include "Camera.h"



class Sky {
public:

	Sky(std::shared_ptr<MyMesh> meshObj, Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerObj, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeMapObj, Microsoft::WRL::ComPtr<ID3D11Device> deviceObj);
	~Sky();
	void DrawSky(Microsoft::WRL::ComPtr<ID3D11DeviceContext> deviceContext, Camera* camera);
	void SetSkyPixelShader(std::shared_ptr<SimplePixelShader> pixShad);
	void SetSkyVertexShader(std::shared_ptr<SimpleVertexShader> vertShad);
	void SetSkyMesh(std::shared_ptr<MyMesh> myMeshObj);

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> GetSkySRV();



private:
	Microsoft::WRL::ComPtr<ID3D11SamplerState> mySampler;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeSRV;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilState> depthBuff;
	Microsoft::WRL::ComPtr<ID3D11RasterizerState> myRasterizer;
	std::shared_ptr<MyMesh> mesh;
	std::shared_ptr<SimpleVertexShader> skyVertShad;
	std::shared_ptr<SimplePixelShader> skyPixShad;
};