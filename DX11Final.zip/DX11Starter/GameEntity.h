#pragma once
#include "Transformations.h"
#include "MyMesh.h"
#include "Camera.h"
#include "Material.h"
#include <iostream>
#include <d3d11.h>
#include <DirectXMath.h>
#include <wrl/client.h>
#include "TerrainData.h"

class GameEntity {
public:

	//Constructor
	GameEntity(std::shared_ptr<MyMesh> meshObj, std::shared_ptr<Material> mat);
	~GameEntity();

	//Getters
	std::shared_ptr<MyMesh> GetMesh();
	Transformations* GetTransform();
	std::shared_ptr<Material> GetMaterial();

	//Draw Method
	void DrawEntity(Microsoft::WRL::ComPtr<ID3D11DeviceContext>	context, Camera* camera);

private:

	//Fields
	Transformations transform;
	std::shared_ptr<MyMesh> myMeshObj;
	std::shared_ptr<Material> myMaterial;
};