#pragma once
#include <DirectXMath.h>
#include <d3d11.h>
#include <wrl/client.h>
#include "SimpleShader.h"
#include <iostream>

class Material
{
public:


	Material(DirectX::XMFLOAT4 clrTint, std::shared_ptr<SimplePixelShader>pShader, std::shared_ptr<SimpleVertexShader>vShader, float specularExpo, Microsoft::WRL::ComPtr <ID3D11SamplerState> samplerState, 
		Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normMap, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> rough,
		Microsoft::WRL::ComPtr< ID3D11ShaderResourceView> metal);
	~Material();

	std::shared_ptr<SimplePixelShader> GetPixelShader();
	std::shared_ptr<SimpleVertexShader> GetVertexShader();
	DirectX::XMFLOAT4 GetTint();
	Microsoft::WRL::ComPtr<ID3D11SamplerState> GetSample();
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> GetTexture();
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> GetNormal();
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> GetRough();
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> GetMetal();
	float GetSpecExpo();
	void SetTint(DirectX::XMFLOAT4 newColor);



private:

	DirectX::XMFLOAT4 colorTint;
	std::shared_ptr<SimpleVertexShader>vertShader;
	std::shared_ptr<SimplePixelShader>pixShader;
	float specExp;
	Microsoft::WRL::ComPtr <ID3D11SamplerState> sampleState;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> textureSet;
	Microsoft::WRL::ComPtr< ID3D11ShaderResourceView> normalSet;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> roughness;
	Microsoft::WRL::ComPtr< ID3D11ShaderResourceView> metalness;
};
