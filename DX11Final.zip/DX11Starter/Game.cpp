#include "Game.h"
#include "Vertex.h"
#include "MyMesh.h"
#include "GameEntity.h"
#include "WICTextureLoader.h"
#include "DDSTextureLoader.h"

// Needed for a helper function to read compiled shader files from the hard drive
#pragma comment(lib, "d3dcompiler.lib")
#include <d3dcompiler.h>

// For the DirectX Math library
using namespace DirectX;

// --------------------------------------------------------
// Constructor
//
// DXCore (base class) constructor will set up underlying fields.
// DirectX itself, and our window, are not ready yet!
//
// hInstance - the application's OS-level handle (unique ID)
// --------------------------------------------------------
Game::Game(HINSTANCE hInstance)
	: DXCore(
		hInstance,		   // The application's handle
		"DirectX Game",	   // Text for the window's title bar
		1280,			   // Width of the window's client area
		720,			   // Height of the window's client area
		true)			   // Show extra stats (fps) in title bar?
{

#if defined(DEBUG) || defined(_DEBUG)
	// Do we want a console window?  Probably only in debug mode
	CreateConsoleWindow(500, 120, 32, 120);
	printf("Console window created successfully.  Feel free to printf() here.\n");
#endif

	transform = Transformations();

	camera = new Camera(0, 21, -1, (float)width / height);
}

// --------------------------------------------------------
// Destructor - Clean up anything our game has created:
//  - Release all DirectX objects created here
//  - Delete any objects to prevent memory leaks
// --------------------------------------------------------
Game::~Game()
{
	// Note: Since we're using smart pointers (ComPtr),
	// we don't need to explicitly clean up those DirectX objects
	// - If we weren't using smart pointers, we'd need
	//   to call Release() on each DirectX object created in Game
	delete camera;

}

// --------------------------------------------------------
// Called once per program, after DirectX and the window
// are initialized but before the game loop.
// --------------------------------------------------------
void Game::Init()
{

	//Create textures from picture files
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/bronze_albedo.png").c_str(),
		0,
		texture1SRV.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/cobblestone_albedo.png").c_str(),
		0,
		texture2SRV.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/floor_albedo.png").c_str(),
		0,
		texture3SRV.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/paint_albedo.png").c_str(),
		0,
		texture4SRV.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/wood_albedo.png").c_str(),
		0,
		texture5SRV.GetAddressOf());

	//Create Normal Maps from picture files
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/bronze_normals.png").c_str(),
		0,
		normalMap1.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/cobblestone_normals.png").c_str(),
		0,
		normalMap2.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/floor_normals.png").c_str(),
		0,
		normalMap3.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/paint_normals.png").c_str(),
		0,
		normalMap4.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/wood_normals.png").c_str(),
		0,
		normalMap5.GetAddressOf());

	//Create Metal Maps from picture files
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/bronze_metal.png").c_str(),
		0,
		metalTexture.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/cobblestone_metal.png").c_str(),
		0,
		metalTexture2.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/floor_metal.png").c_str(),
		0,
		metalTexture3.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/paint_metal.png").c_str(),
		0,
		metalTexture4.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/wood_metal.png").c_str(),
		0,
		metalTexture5.GetAddressOf());

	//Create roughness Maps from picture files
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/bronze_roughness.png").c_str(),
		0,
		roughnessTexture.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/cobblestone_roughness.png").c_str(),
		0,
		roughnessTexture2.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/floor_roughness.png").c_str(),
		0,
		roughnessTexture3.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/paint_roughness.png").c_str(),
		0,
		roughnessTexture4.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/wood_roughness.png").c_str(),
		0,
		roughnessTexture5.GetAddressOf());


	//Start creation of terrain image data
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Heightmap/blendmap.png").c_str(),
		0,
		terrainBlendMap.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/stone_albedo.tif").c_str(),
		0,
		terrainTex1.GetAddressOf());
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/moss_albedo.tif").c_str(),
		0,
		terrainTex2.GetAddressOf());
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/snow_albedo.tif").c_str(),
		0,
		terrainTex3.GetAddressOf());

	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/stone_normal.tif").c_str(),
		0,
		terrainNorm1.GetAddressOf());
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/moss_normal.tif").c_str(),
		0,
		terrainNorm2.GetAddressOf());
	CreateWICTextureFromFile(
		device.Get(),
		context.Get(),
		GetFullPathTo_Wide(L"../../Assets/Textures/snow_normal.tif").c_str(),
		0,
		terrainNorm3.GetAddressOf());


	//Create Skybox from DDS file
	CreateDDSTextureFromFile(
		device.Get(),
		GetFullPathTo_Wide(L"../../Assets/Skies/SunnyCubeMap.dds").c_str(),
		0,
		cubeMapObj.GetAddressOf());


	//Create Sampler Description
	D3D11_SAMPLER_DESC sampDesc = {};
	sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.Filter = D3D11_FILTER_ANISOTROPIC;
	sampDesc.MaxAnisotropy = 16;
	sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
	device->CreateSamplerState(&sampDesc, sampler.GetAddressOf());

	// Helper methods for loading shaders, creating some basic
	// geometry to draw and some simple camera matrices.
	//  - You'll be expanding and/or replacing these later
	LoadShaders();
	CreateBasicGeometry();
	
	// Tell the input assembler stage of the pipeline what kind of
	// geometric primitives (points, lines or triangles) we want to draw.  
	// Essentially: "What kind of shape should the GPU draw with our data?"
	context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	ambientColor = XMFLOAT3(1.0f, 1.0f, 1.0f);	//Setting ambient Color
	
	light.color = XMFLOAT3(1.0f, 1.0f, 1.0f);	//Creation of first light
	light.intensity = 1.0f;
	light.direction = XMFLOAT3(1, -1, 0);
	
	light2.color = XMFLOAT3(1.0f, 1.0f, 1.0f);	//Creation of second light
	light2.intensity = 1.5f;
	light2.direction = XMFLOAT3(0, 1, -1);

	light3.color = XMFLOAT3(1.0f, 1.0f, 1.0f);	//Creation of third light
	light3.intensity = 1.0f;
	light3.direction = XMFLOAT3(0, -1, 1);

	skyObj = std::make_shared<Sky>(skyMeshObj, sampler, cubeMapObj, device);
	skyObj->SetSkyPixelShader(skyPixShad);
	skyObj->SetSkyVertexShader(skyVertShad);

}

// --------------------------------------------------------
// Loads shaders from compiled shader object (.cso) files
// and also created the Input Layout that describes our 
// vertex data to the rendering pipeline. 
// - Input Layout creation is done here because it must 
//    be verified against vertex shader byte code
// - We'll have that byte code already loaded below
// --------------------------------------------------------
void Game::LoadShaders()
{
	vertShad = std::make_shared<SimpleVertexShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"VertexShader.cso").c_str());
	pixShad = std::make_shared<SimplePixelShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"PixelShader.cso").c_str());
	vertShadNormal = std::make_shared<SimpleVertexShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"NormalMapVertexShader.cso").c_str());
	pixShadNormal = std::make_shared<SimplePixelShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"NormalMapPixelShader.cso").c_str());
	skyVertShad = std::make_shared<SimpleVertexShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"SkyBoxVertexShader.cso").c_str());
	skyPixShad = std::make_shared<SimplePixelShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"SkyBoxPixelShader.cso").c_str());
	pbrPixShad = std::make_shared<SimplePixelShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"PixelShaderPBR.cso").c_str());
	terrainPixShad = std::make_shared<SimplePixelShader>(device.Get(), context.Get(), GetFullPathTo_Wide(L"TerrainPixelShader.cso").c_str());
	
	pixShadArray.push_back(pixShad);
	pixShadArray.push_back(pixShadNormal);
	pixShadArray.push_back(pbrPixShad);
	pixShadArray.push_back(terrainPixShad);
}



// --------------------------------------------------------
// Creates the geometry we're going to draw - a single triangle for now
// --------------------------------------------------------
void Game::CreateBasicGeometry()
{
	//Create mesh objects that are 3D Geometric shapes
	mesh1 = std::make_shared<MyMesh>(GetFullPathTo("../../Assets/Models/cube.obj").c_str(),device);
	mesh2 = std::make_shared<MyMesh>(GetFullPathTo("../../Assets/Models/cylinder.obj").c_str(), device);
	mesh3 = std::make_shared<MyMesh>(GetFullPathTo("../../Assets/Models/helix.obj").c_str(), device);
	mesh4 = std::make_shared<MyMesh>(GetFullPathTo("../../Assets/Models/sphere.obj").c_str(), device);
	mesh5 = std::make_shared<MyMesh>(GetFullPathTo("../../Assets/Models/torus.obj").c_str(), device);

	terrainMesh = std::make_shared<TerrainData>(device, GetFullPathTo("../../Assets/HeightMap/heightmap.raw").c_str(), 513,513,BitDepth_16,15.0f,1.0f,1.0f);

	skyMeshObj = mesh4;
	

	//Create Materials Here
	matRed = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), pbrPixShad, vertShadNormal, 10.0f, sampler, texture1SRV, normalMap1, roughnessTexture, metalTexture);
	matBlue = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), pbrPixShad, vertShadNormal, 5.0f, sampler, texture2SRV, normalMap2, roughnessTexture2, metalTexture2);
	matPurple = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), pbrPixShad, vertShadNormal, 2.5f, sampler, texture3SRV, normalMap3, roughnessTexture3, metalTexture3);
	matWhite = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), pbrPixShad, vertShadNormal, 1.0f, sampler, texture4SRV, normalMap4, roughnessTexture4, metalTexture4);
	matBlack = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), pbrPixShad, vertShadNormal, 1.5f, sampler, texture5SRV, normalMap5, roughnessTexture5, metalTexture5);

	terrainMat1 = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), terrainPixShad, vertShadNormal, 1.5f, sampler, terrainTex1, terrainNorm1, nullptr, nullptr);
	terrainMat2 = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), terrainPixShad, vertShadNormal, 1.5f, sampler, terrainTex2, terrainNorm2, nullptr, nullptr);
	terrainMat3 = std::make_shared<Material>(XMFLOAT4(1, 1, 1, 1), terrainPixShad, vertShadNormal, 1.5f, sampler, terrainTex3, terrainNorm3, nullptr, nullptr);

	//Create entities here
	entity1 = std::make_shared<GameEntity>(mesh1, matWhite);
	entity2 = std::make_shared<GameEntity>(mesh2, matBlue);
	entity3 = std::make_shared<GameEntity>(mesh3, matPurple);
	entity4 = std::make_shared<GameEntity>(mesh4, matRed);
	entity5 = std::make_shared<GameEntity>(mesh5, matBlack);

	terrainEntity = std::make_shared<GameEntity>(terrainMesh, terrainMat1);

	//Set entity positions to be able to see all
	entity1.get()->GetTransform()->SetPosition(-5, 0, 0);
	entity2.get()->GetTransform()->SetPosition(-2.5, 0, 0);
	entity3.get()->GetTransform()->SetPosition(0, 0, 0);
	entity4.get()->GetTransform()->SetPosition(2.5, 0, 0);
	entity5.get()->GetTransform()->SetPosition(5, 0, 0);

	terrainEntity.get()->GetTransform()->SetPosition(0, -15, 0);

	entityArray.push_back(entity1);
	entityArray.push_back(entity2);
	entityArray.push_back(entity3);
	entityArray.push_back(entity4);
	entityArray.push_back(entity5);
	entityArray.push_back(terrainEntity);

}


// --------------------------------------------------------
// Handle resizing DirectX "stuff" to match the new window size.
// For instance, updating our projection matrix's aspect ratio.
// --------------------------------------------------------
void Game::OnResize()
{
	// Handle base-level DX resize stuff
	DXCore::OnResize();

	camera->UpdateProjectionMatrix((float)width/height);
}

// --------------------------------------------------------
// Update your game here - user input, move objects, AI, etc.
// --------------------------------------------------------
void Game::Update(float deltaTime, float totalTime)
{
	// Quit if the escape key is pressed
	if (GetAsyncKeyState(VK_ESCAPE))
		Quit();

	

	camera->Update(deltaTime, this->hWnd);
}

// --------------------------------------------------------
// Clear the screen, redraw everything, present to the user
// --------------------------------------------------------
void Game::Draw(float deltaTime, float totalTime)
{
	// Background color (Cornflower Blue in this case) for clearing
	const float color[4] = { 0.4f, 0.6f, 0.75f, 0.0f };

	// Clear the render target and depth buffer (erases what's on the screen)
	//  - Do this ONCE PER FRAME
	//  - At the beginning of Draw (before drawing *anything*)
	context->ClearRenderTargetView(backBufferRTV.Get(), color);
	context->ClearDepthStencilView(
		depthStencilView.Get(),
		D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL,
		1.0f,
		0);



	// Ensure the pipeline knows how to interpret the data (numbers)
	// from the vertex buffer.  
	// - If all of your 3D models use the exact same vertex layout,
	//    this could simply be done once in Init()
	// - However, this isn't always the case (but might be for this course)

	//Looping through entity vector array list
	for (std::shared_ptr<GameEntity> i : entityArray) {
		std::shared_ptr<SimplePixelShader> currentPS = i->GetMaterial()->GetPixelShader();
		currentPS->SetData(
			"light",
			&light,
			sizeof(DirectionalLight));

		currentPS->SetData(
			"light2",
			&light2,
			sizeof(DirectionalLight));

		currentPS->SetData(
			"light3",
			&light3,
			sizeof(DirectionalLight));
		currentPS->SetFloat3("cameraPosition", camera->GetTransform()->GetPosition());
		currentPS->SetFloat("specularExponent", i->GetMaterial()->GetSpecExpo());
		currentPS->SetSamplerState("Sampler", i->GetMaterial()->GetSample().Get());
		currentPS->SetShaderResourceView("Albedo", i->GetMaterial()->GetTexture().Get());
		currentPS->SetShaderResourceView("NormalMap", i->GetMaterial()->GetNormal().Get());
		currentPS->SetShaderResourceView("RoughnessMap", i->GetMaterial()->GetRough().Get());
		currentPS->SetShaderResourceView("MetalnessMap", i->GetMaterial()->GetMetal().Get());
		
		currentPS->SetFloat("stoneScale", 50.0f);
		currentPS->SetFloat("grassScale", 50.0f);
		currentPS->SetFloat("snowScale", 50.0f);
		currentPS->SetShaderResourceView("blendTex", i->GetMaterial()->GetTexture().Get());
		currentPS->SetShaderResourceView("stoneTex", i->GetMaterial()->GetTexture().Get());
		currentPS->SetShaderResourceView("grassTex", i->GetMaterial()->GetTexture().Get());
		currentPS->SetShaderResourceView("snowTex", i->GetMaterial()->GetTexture().Get());
		currentPS->SetShaderResourceView("stoneNorm", i->GetMaterial()->GetNormal().Get());
		currentPS->SetShaderResourceView("grassNorm", i->GetMaterial()->GetNormal().Get());
		currentPS->SetShaderResourceView("snowNorm", i->GetMaterial()->GetNormal().Get());
		currentPS->CopyAllBufferData();
		i.get()->DrawEntity(context, camera);	//setting the specular exponent, the sampler and the texture, and normal map then copying and drawing all entities
	}
	skyObj->DrawSky(context, camera);


	// Present the back buffer to the user
	//  - Puts the final frame we're drawing into the window so the user can see it
	//  - Do this exactly ONCE PER FRAME (always at the very end of the frame)
	swapChain->Present(0, 0);

	// Due to the usage of a more sophisticated swap chain,
	// the render target must be re-bound after every call to Present()
	context->OMSetRenderTargets(1, backBufferRTV.GetAddressOf(), depthStencilView.Get());
}