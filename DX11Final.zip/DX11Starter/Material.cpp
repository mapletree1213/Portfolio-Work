#include "Material.h"

Material::Material(DirectX::XMFLOAT4 clrTint, std::shared_ptr<SimplePixelShader>pShader, std::shared_ptr<SimpleVertexShader>vShader, float specularExpo, Microsoft::WRL::ComPtr <ID3D11SamplerState> samplerState,
    Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normMap, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> rough,
    Microsoft::WRL::ComPtr< ID3D11ShaderResourceView> metal)
{
    colorTint = clrTint;
    pixShader = pShader;
    vertShader = vShader;
    specExp = specularExpo;
    sampleState = samplerState;
    textureSet = texture;
    normalSet = normMap;
    roughness = rough;
    metalness = metal;
}

Material::~Material()
{
}

std::shared_ptr<SimplePixelShader> Material::GetPixelShader()
{
    return pixShader;
}

std::shared_ptr<SimpleVertexShader> Material::GetVertexShader()
{
    return vertShader;
}

DirectX::XMFLOAT4 Material::GetTint()
{
    return colorTint;
}

Microsoft::WRL::ComPtr<ID3D11SamplerState> Material::GetSample()
{
    return sampleState;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Material::GetTexture()
{
    return textureSet;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Material::GetNormal()
{
    return normalSet;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Material::GetRough()
{
    return roughness;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> Material::GetMetal()
{
    return metalness;
}

float Material::GetSpecExpo()
{
    return specExp;
}

void Material::SetTint(DirectX::XMFLOAT4 newColor)
{
    newColor = colorTint;
}
