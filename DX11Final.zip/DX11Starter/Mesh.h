#pragma once
#include "DXCore.h"
#include <d3d11.h>
#include <DirectXMath.h>
#include <wrl/client.h>
#include "Vertex.h"

class Mesh {

public:

	Microsoft::WRL::ComPtr<ID3D11Buffer> GetVertexBuffer() {
		return vertexBuffer;
	}
	Microsoft::WRL::ComPtr<ID3D11Buffer> GetIndexBuffer() {
		return indexBuffer;
	}
	int GetIndexCount() {
		return indexCnt;
	}

	Mesh(Vertex vertices[], int numOfVerts, unsigned int indices[], int numOfInd, Microsoft::WRL::ComPtr<ID3D11Device> deviceObj) {
		indexCnt = numOfInd;
	}
	~Mesh();



private:
	Microsoft::WRL::ComPtr<ID3D11Buffer> vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> indexBuffer;
	int indexCnt;

};