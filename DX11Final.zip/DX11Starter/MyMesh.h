#pragma once
#include "DXCore.h"
#include <d3d11.h>
#include <DirectXMath.h>
#include <wrl/client.h>
#include "Vertex.h"
#include <iostream>
#include <fstream>
#include <vector>


class MyMesh {

public:

	Microsoft::WRL::ComPtr<ID3D11Buffer> GetVertexBuffer() {
		return vertexBuffer;
	}
	Microsoft::WRL::ComPtr<ID3D11Buffer> GetIndexBuffer() {
		return indexBuffer;
	}
	int GetIndexCount() {
		return indexCnt;
	}

	MyMesh(Vertex vertices[], int numOfVerts, unsigned int indices[], int numOfInd, Microsoft::WRL::ComPtr<ID3D11Device> deviceObj);
	MyMesh(const char* fileName, Microsoft::WRL::ComPtr<ID3D11Device>deviceObj);
	MyMesh();
	void CalculateTangents(Vertex* verts, int numVerts, unsigned int* indices, int numIndices);
	~MyMesh();

	void CreateBuffers(Vertex vertices[], int numOfVerts, unsigned int indices[], int numOfInd, Microsoft::WRL::ComPtr<ID3D11Device> deviceObj);

	void DrawMesh(Microsoft::WRL::ComPtr<ID3D11DeviceContext> context);



protected: 
	Microsoft::WRL::ComPtr<ID3D11Buffer> vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> indexBuffer;
	int indexCnt;

};