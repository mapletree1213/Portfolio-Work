#include "GameEntity.h"
#include "DXCore.h"
#include <iostream>

using namespace DirectX;

GameEntity::GameEntity(std::shared_ptr<MyMesh> meshObj, std::shared_ptr<Material> mat)
{
	myMeshObj = meshObj;
	myMaterial = mat;

}

GameEntity::~GameEntity()
{
}

std::shared_ptr<MyMesh> GameEntity::GetMesh()
{
	return myMeshObj;
}

Transformations* GameEntity::GetTransform()
{
	return &transform;
}

std::shared_ptr<Material> GameEntity::GetMaterial() {
	return myMaterial;
}

void GameEntity::DrawEntity(Microsoft::WRL::ComPtr<ID3D11DeviceContext>	context, Camera* camera)
{

	// Set the vertex and pixel shaders to use for the next Draw() command
	//  - These don't technically need to be set every frame
	//  - Once you start applying different shaders to different objects,
	//    you'll need to swap the current shaders before each draw
	myMaterial->GetVertexShader()->SetShader();
	myMaterial->GetPixelShader()->SetShader();
	std::shared_ptr<SimpleVertexShader> vs = myMaterial->GetVertexShader();
	vs->SetFloat4("colorTint", myMaterial->GetTint());
	vs->SetMatrix4x4("world", transform.GetWorldMatrix());
	vs->SetMatrix4x4("view", camera->GetViewMatrix());
	vs->SetMatrix4x4("projection", camera->GetProjMatrix());

	vs->CopyAllBufferData();


	// Set buffers in the input assembler
	//  - Do this ONCE PER OBJECT you're drawing, since each object might
	//    have different geometry.
	//  - for this demo, this step *could* simply be done once during Init(),
	//    but I'm doing it here because it's often done multiple times per frame
	//    in a larger application/game
	UINT stride = sizeof(Vertex);
	UINT offset = 0;
	context->IASetVertexBuffers(0, 1, myMeshObj->GetVertexBuffer().GetAddressOf(), &stride, &offset);
	context->IASetIndexBuffer(myMeshObj->GetIndexBuffer().Get(), DXGI_FORMAT_R32_UINT, 0);


	// Finally do the actual drawing
	//  - Do this ONCE PER OBJECT you intend to draw
	//  - This will use all of the currently set DirectX "stuff" (shaders, buffers, etc)
	//  - DrawIndexed() uses the currently set INDEX BUFFER to look up corresponding
	//     vertices in the currently set VERTEX BUFFER

	context->DrawIndexed(
		myMeshObj->GetIndexCount(),     // The number of indices to use (we could draw a subset if we wanted)
		0,     // Offset to the first index we want to use
		0);    // Offset to add to each index when looking up vertices

}
