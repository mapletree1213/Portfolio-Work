#pragma once
#include <Windows.h>
#include <DirectXMath.h>
#include "Transformations.h"

class Camera {
public:
	Camera(float x, float y, float z, float aR);
	~Camera();

	void UpdateProjectionMatrix(float aspectRatio);
	void UpdateViewMatrix();
	void Update(float dt, HWND windowHandle);

	DirectX::XMFLOAT4X4 GetViewMatrix();
	DirectX::XMFLOAT4X4 GetProjMatrix();
	Transformations* Camera::GetTransform();


private:
	Transformations cameraTransform;
	DirectX::XMFLOAT4X4 viewMatrix;
	DirectX::XMFLOAT4X4 projMatrix;
	POINT prevMousePos;
};