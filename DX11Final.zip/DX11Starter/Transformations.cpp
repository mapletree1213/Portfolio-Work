#include "Transformations.h"

using namespace DirectX;

Transformations::Transformations() {
	pos = XMFLOAT3(0, 0, 0);
	rotation = XMFLOAT3(0, 0, 0);
	scale = XMFLOAT3(1,1,1);
	XMStoreFloat4x4(&worldMatrix, XMMatrixIdentity());
	notUpdated = false;

}

Transformations::~Transformations()
{
}

//Setters
void Transformations::SetPosition(float x, float y, float z)
{
	pos.x = x;
	pos.y = y;
	pos.z = z;
	notUpdated = true;
}

void Transformations::SetRotation(float pitch, float yaw, float roll)
{
	rotation.x = pitch;
	rotation.y = yaw;
	rotation.z = roll;
	notUpdated = true;
}

void Transformations::SetScale(float x, float y, float z)
{
	scale.x = x;
	scale.y = y;
	scale.z = z;
	notUpdated = true;
}

//Transformers
void Transformations::Move(float x, float y, float z)
{
	XMVECTOR newPos = XMVectorAdd(XMLoadFloat3(&pos), XMVectorSet(x, y, z, 0));
	XMStoreFloat3(&pos, newPos);
	notUpdated = true;
}

void Transformations::MoveRelative(float x, float y, float z)
{
	XMVECTOR relativePos = XMVectorSet(x,y,z,0);
	XMVECTOR relativeRotation = XMQuaternionRotationRollPitchYawFromVector(XMLoadFloat3(&rotation));
	XMVECTOR relativeMovement = XMVector3Rotate(relativePos, relativeRotation);
	XMStoreFloat3(&pos, XMLoadFloat3(&pos) + relativeMovement);
}

void Transformations::Rotate(float pitch, float yaw, float roll)
{
	rotation.x += pitch;
	rotation.y += yaw;
	rotation.z += roll;
	notUpdated = true;
}

void Transformations::Scale(float x, float y, float z)
{
	scale.x += x;
	scale.y += y;
	scale.z += z;
	notUpdated = true;
}

//Getters
DirectX::XMFLOAT3 Transformations::GetPosition()
{
	return pos;
}

DirectX::XMFLOAT3 Transformations::GetRotation()
{
	return rotation;
}

DirectX::XMFLOAT3 Transformations::GetScale()
{
	return scale;
}

DirectX::XMFLOAT4X4 Transformations::GetWorldMatrix()
{
	if (notUpdated) {
		XMMATRIX transMat = XMMatrixTranslationFromVector(XMLoadFloat3(&pos));
		XMMATRIX transRotMat = XMMatrixRotationRollPitchYawFromVector(XMLoadFloat3(&rotation));
		XMMATRIX transScaleMat = XMMatrixScalingFromVector(XMLoadFloat3(&scale));

		XMMATRIX worldMat = transScaleMat * transRotMat * transMat;

		XMStoreFloat4x4(&worldMatrix, worldMat);
		notUpdated = false;
	}

	return worldMatrix;
}
