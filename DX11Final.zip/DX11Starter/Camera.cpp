#include "Camera.h"

using namespace DirectX;

Camera::Camera(float x, float y, float z, float aR)
{
	cameraTransform.SetPosition(x, y, z);
	UpdateViewMatrix();
	UpdateProjectionMatrix(aR);
}

Camera::~Camera()
{
}

void Camera::UpdateProjectionMatrix(float aspectRatio)
{
	XMMATRIX projection = XMMatrixPerspectiveFovLH(
		XM_PIDIV4,
		aspectRatio,
		0.01f,
		100.0f);

	XMStoreFloat4x4(&projMatrix, projection);
}

void Camera::UpdateViewMatrix()
{
	XMFLOAT3 pyrVals = cameraTransform.GetRotation();
	XMVECTOR fwdDir = XMVector3Rotate(XMVectorSet(0,0,1,0),XMQuaternionRotationRollPitchYawFromVector(XMLoadFloat3(&pyrVals)));
	XMFLOAT3 pos = cameraTransform.GetPosition();
	XMMATRIX viewMat = XMMatrixLookToLH(XMLoadFloat3(&pos),fwdDir,XMVectorSet(0,1,0,0));

	XMStoreFloat4x4(&viewMatrix, viewMat);

}

void Camera::Update(float dt, HWND windowHandle)
{
	float camMoveSpeed = dt * 2.0f;

	if (GetAsyncKeyState('W') & 0x8000) {
		cameraTransform.MoveRelative(0, 0, camMoveSpeed);
	}
	if (GetAsyncKeyState('A') & 0x8000) {
		cameraTransform.MoveRelative(-camMoveSpeed, 0, 0);
	}
	if (GetAsyncKeyState('S') & 0x8000) {
		cameraTransform.MoveRelative(0, 0, -camMoveSpeed);
	}
	if (GetAsyncKeyState('D') & 0x8000) {
		cameraTransform.MoveRelative(camMoveSpeed, 0, 0);
	}
	if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
		cameraTransform.Move(0, camMoveSpeed, 0);
	}
	if (GetAsyncKeyState('X') & 0x8000) {
		cameraTransform.Move(0, -camMoveSpeed, 0);
	}
	
	POINT mousePos = {};
	GetCursorPos(&mousePos);
	ScreenToClient(windowHandle, &mousePos);

	if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
		float mouseSpeed = 3.0f;
		float xDiff = mouseSpeed * dt * (mousePos.x - prevMousePos.x);
		float yDiff = mouseSpeed * dt * (mousePos.y - prevMousePos.y);
		cameraTransform.Rotate(yDiff, xDiff, 0);
	}
	
	UpdateViewMatrix();

	prevMousePos = mousePos;
}

DirectX::XMFLOAT4X4 Camera::GetViewMatrix()
{
	return viewMatrix;
}

DirectX::XMFLOAT4X4 Camera::GetProjMatrix()
{
	return projMatrix;
}

Transformations* Camera::GetTransform()
{
	return &cameraTransform;
}
