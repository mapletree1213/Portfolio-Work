#include "TerrainData.h"

using namespace DirectX;

TerrainData::TerrainData(Microsoft::WRL::ComPtr<ID3D11Device> deviceObj, const char* heightMap, unsigned int mapHeight,  unsigned int mapWidth, TerrainBD bd, float heightScale, float lenWidScale, float uv) : MyMesh()
{
	bd = BitDepth_8;
	verticies = mapWidth * mapHeight;
	indicies = (mapHeight - 1) * (mapHeight - 1) * 6;
	vert = new Vertex[verticies];
	if (bd == BitDepth_8) {
		LoadRaw8Bit(heightMap, mapHeight, mapWidth, heightScale, lenWidScale, vert);
	}
	else {
		LoadRaw16Bit(heightMap, mapHeight, mapWidth, heightScale, lenWidScale, vert);
	}
	inds = new unsigned int[indicies];
	std::vector<XMFLOAT3> normsForTerrain;
	counter = 0;
	for (int h = 0; h < mapHeight - 1; h++) {
		for (int w = 0; w < mapWidth - 1; w++) {
			int index0 = h * mapWidth + w;	//Vertex Index
			int index1 = (mapHeight * h) + w;	//BL
			int index2 = (mapHeight * h) + (w+1);	//BR
			int index3 = (mapHeight * (h+1)) + w;	//TL
			int index4 = (mapHeight * (h+1)) + (w+1);	//TR

			inds[counter++] = index0;
			inds[counter++] = index4;
			inds[counter++] = index2;
			inds[counter++] = index0;
			inds[counter++] = index3;
			inds[counter++] = index4;

			XMVECTOR vertInd = XMLoadFloat3(&vert[index0].Position);
			XMVECTOR bottomLeft = XMLoadFloat3(&vert[index1].Position);
			XMVECTOR bottomRight = XMLoadFloat3(&vert[index2].Position);
			XMVECTOR topLeft = XMLoadFloat3(&vert[index3].Position);
			XMVECTOR topRight = XMLoadFloat3(&vert[index4].Position);

			XMFLOAT3 norms1;
			XMFLOAT3 norms2;

			XMStoreFloat3(&norms1, XMVector3Normalize(XMVector3Cross(bottomLeft - vertInd, bottomRight - vertInd)));
			XMStoreFloat3(&norms2, XMVector3Normalize(XMVector3Cross(topLeft - vertInd, topRight - vertInd)));


			normsForTerrain.push_back(norms1);
			normsForTerrain.push_back(norms2);
		}
	}

	for (int h = 0; h < mapHeight; h++) {
		for (int w = 0; w < mapWidth; w++) {
			int ind = h * mapWidth + w;
			int triangleInd = ind * 2 - (2 * h);
			int trianglePrevInd = triangleInd - (mapWidth * 2 - 1);

			int count = 0;
			XMVECTOR normSum = XMVectorSet(0, 0, 0, 0);

			if (h > 0 && w > 0)
			{
				normSum += XMLoadFloat3(&normsForTerrain[trianglePrevInd - 1]);
				normSum += XMLoadFloat3(&normsForTerrain[trianglePrevInd]);
				count += 2;
			}

			if (h > 0 && w < mapWidth - 1)
			{
				normSum += XMLoadFloat3(&normsForTerrain[trianglePrevInd + 1]);
				count++;
			}

			if (h < mapHeight - 1 && w > 0)
			{
				normSum += XMLoadFloat3(&normsForTerrain[triangleInd - 1]);
				count++;
			}

			if (h < mapHeight - 1 && w < mapWidth - 1)
			{
				normSum += XMLoadFloat3(&normsForTerrain[triangleInd]);
				normSum += XMLoadFloat3(&normsForTerrain[triangleInd + 1]);
				count += 2;
			}
			normSum /= count;
			XMStoreFloat3(&vert[ind].Normal, normSum);

		}
	}

	this->indexCnt = indicies;

	this->CreateBuffers(vert, verticies, inds, indicies, deviceObj);
	delete[] vert;
	delete[] inds;
}

TerrainData::~TerrainData()
{
}


void TerrainData::LoadRaw8Bit(const char* heightMap, unsigned int mapHeight, unsigned int mapWidth, float heightScale, float lenWidScale, Vertex* vertex)
{
	unsigned int numVertices = mapWidth * mapHeight;
	float halfWidth = mapWidth / 2.0f;
	float halfHeight = mapHeight / 2.0f;

	// Vector to hold heights
	std::vector<unsigned char> heights(numVertices);

	// Open the file (remember to #include <fstream>)
	std::ifstream file;
	file.open(heightMap, std::ios_base::binary);
	if (!file)
		return;

	// Read raw bytes to vector
	file.read((char*)&heights[0], numVertices); // Same size
	file.close();

	// Create the initial mesh data
	for (int z = 0; z < mapHeight; z++)
	{
		for (int x = 0; x < mapWidth; x++)
		{
			// This vert index
			int index = z * mapWidth + x;

			// Set up this vertex
			vert[index] = {};

			// Position on a regular grid, heights from heightmap
			vert[index].Position.x = (x - halfWidth) * lenWidScale;
			vert[index].Position.y = (heights[index] / 255.0f) * heightScale;
			vert[index].Position.z = (z - halfHeight) * lenWidScale;

			// Assume we're starting flat
			vert[index].Normal.x = 0.0f;
			vert[index].Normal.y = 1.0f;
			vert[index].Normal.z = 0.0f;

			// Simple UV (0-1)
			vert[index].UV.x = x / (float)mapWidth;
			vert[index].UV.y = z / (float)mapHeight;
		}
	}
}

void TerrainData::LoadRaw16Bit(const char* heightMap, unsigned int mapHeight, unsigned int mapWidth, float heightScale, float lenWidScale, Vertex* vertex)
{
	unsigned int numVertices = mapWidth * mapHeight;
	float halfWidth = mapWidth / 2.0f;
	float halfHeight = mapHeight / 2.0f;

	std::vector<unsigned short> heights(numVertices);

	std::ifstream file;
	file.open(heightMap, std::ios_base::binary);
	if (!file)
		return;

	file.read((char*)&heights[0], numVertices * 2);
	file.close();

	for (int z = 0; z < mapHeight; z++)
	{
		for (int x = 0; x < mapWidth; x++)
		{

			int index = z * mapWidth + x;

			vert[index] = {};
			vert[index].Position.x = (x - halfWidth) * lenWidScale;
			vert[index].Position.y = (heights[index] / 65535.0f) * heightScale;
			vert[index].Position.z = (z - halfHeight) * lenWidScale;

			vert[index].Normal.x = 0.0f;
			vert[index].Normal.y = 1.0f;
			vert[index].Normal.z = 0.0f;

			vert[index].UV.x = x / (float)mapWidth;
			vert[index].UV.y = z / (float)mapHeight;
		}
	}
}
