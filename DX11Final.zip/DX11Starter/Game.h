#pragma once

#include <iostream>
#include <fstream>
#include "DXCore.h"
#include "MyMesh.h"
#include "GameEntity.h"
#include "Transformations.h"
#include "Vertex.h"
#include "Camera.h"
#include "Lights.h"
#include "Sky.h"
#include "SimpleShader.h"
#include <DirectXMath.h>
#include <wrl/client.h> // Used for ComPtr - a smart pointer for COM objects
#include "TerrainData.h"

class Game 
	: public DXCore
{

public:
	Game(HINSTANCE hInstance);
	~Game();

	// Overridden setup and game loop methods, which
	// will be called automatically
	void Init();
	void OnResize();
	void Update(float deltaTime, float totalTime);
	void Draw(float deltaTime, float totalTime);



private:

	// Initialization helper methods - feel free to customize, combine, etc.
	void LoadShaders(); 
	void CreateBasicGeometry();

	std::shared_ptr<MyMesh> mesh1;
	std::shared_ptr<MyMesh> mesh2;
	std::shared_ptr<MyMesh> mesh3;
	std::shared_ptr<MyMesh> mesh4;
	std::shared_ptr<MyMesh> mesh5;
	std::shared_ptr<MyMesh> skyMeshObj;

	std::shared_ptr<MyMesh> terrainMesh;

	std::shared_ptr<GameEntity> entity1;
	std::shared_ptr<GameEntity> entity2;
	std::shared_ptr<GameEntity> entity3;
	std::shared_ptr<GameEntity> entity4;
	std::shared_ptr<GameEntity> entity5;

	std::shared_ptr<GameEntity> terrainEntity;

	//Create shared ptr vector of entities
	std::vector<std::shared_ptr<GameEntity>> entityArray;
 
	std::shared_ptr<Material> matRed;
	std::shared_ptr<Material> matBlue;
	std::shared_ptr<Material> matWhite;
	std::shared_ptr<Material> matPurple;
	std::shared_ptr<Material> matBlack;

	std::shared_ptr<Material> terrainMat1;
	std::shared_ptr<Material> terrainMat2;
	std::shared_ptr<Material> terrainMat3;

	std::shared_ptr<Sky> skyObj;
	

	// Note the usage of ComPtr below
	//  - This is a smart pointer for objects that abide by the
	//    Component Object Model, which DirectX objects do
	//  - More info here: https://github.com/Microsoft/DirectXTK/wiki/ComPtr

	// Buffers to hold actual geometry data
	Microsoft::WRL::ComPtr<ID3D11Buffer> vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> indexBuffer;
	
	// Shaders and shader-related constructs
	std::shared_ptr<SimplePixelShader> pixShad;
	std::shared_ptr<SimpleVertexShader> vertShad;

	std::shared_ptr<SimplePixelShader> pixShadNormal;
	std::shared_ptr<SimpleVertexShader> vertShadNormal;

	std::shared_ptr<SimplePixelShader> skyPixShad;
	std::shared_ptr<SimpleVertexShader> skyVertShad;

	std::shared_ptr<SimplePixelShader> pbrPixShad;

	std::shared_ptr<SimplePixelShader> terrainPixShad;

	std::vector<std::shared_ptr<SimplePixelShader>> pixShadArray;


	Transformations transform;

	Camera* camera;

	DirectionalLight light;
	DirectionalLight light2;
	DirectionalLight light3;

	DirectX::XMFLOAT3 ambientColor;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture1SRV;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture2SRV;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture3SRV;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture4SRV;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture5SRV;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normalMap1;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normalMap2;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normalMap3;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normalMap4;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> normalMap5;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> metalTexture;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> metalTexture2;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> metalTexture3;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> metalTexture4;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> metalTexture5;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> roughnessTexture;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> roughnessTexture2;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> roughnessTexture3;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> roughnessTexture4;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> roughnessTexture5;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeMapObj;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainBlendMap;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainTex1;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainTex2;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainTex3;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainNorm1;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainNorm2;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> terrainNorm3;


	Microsoft::WRL::ComPtr <ID3D11SamplerState> sampler;




};

